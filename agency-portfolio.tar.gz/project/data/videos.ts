export interface VideoItem {
  id: string;
  title: string;
  client: string;
  type: 'ad' | 'reel' | 'brand-film' | 'social';
  thumbnail: string;
  videoUrl: string;
  services: string[];
  kpis?: {
    views?: number;
    clicks?: number;
    engagement?: string;
  };
}

export const videos: VideoItem[] = [
  {
    id: '1',
    title: 'Instagram Reel - Product Showcase',
    client: 'Fashion Brand X',
    type: 'reel',
    thumbnail: '/images/videos/video1.jpg',
    videoUrl: '/videos/sample1.mp4',
    services: ['Script', 'Production', 'Edit', 'Color Grading'],
    kpis: {
      views: 1200000,
      clicks: 45000,
      engagement: '8.2%'
    }
  },
  {
    id: '2',
    title: 'Meta Ad - Sale Campaign',
    client: 'E-commerce Store',
    type: 'ad',
    thumbnail: '/images/videos/video2.jpg',
    videoUrl: '/videos/sample2.mp4',
    services: ['Concept', 'Production', 'Edit', 'Motion Graphics'],
    kpis: {
      views: 850000,
      clicks: 32000,
      engagement: '4.5%'
    }
  },
  {
    id: '3',
    title: 'Brand Story Film',
    client: 'Tech Startup Y',
    type: 'brand-film',
    thumbnail: '/images/videos/video3.jpg',
    videoUrl: '/videos/sample3.mp4',
    services: ['Script', 'Production', 'Cinematography', 'Edit', 'Color Grading', 'Sound Design'],
    kpis: {
      views: 450000,
      engagement: '12.5%'
    }
  },
  {
    id: '4',
    title: 'TikTok Content Series',
    client: 'Beauty Brand B',
    type: 'social',
    thumbnail: '/images/videos/video4.jpg',
    videoUrl: '/videos/sample4.mp4',
    services: ['Concept', 'Production', 'Edit'],
    kpis: {
      views: 2500000,
      engagement: '15.8%'
    }
  },
  {
    id: '5',
    title: 'Product Demo Ad',
    client: 'Tech Gadget Brand',
    type: 'ad',
    thumbnail: '/images/videos/video5.jpg',
    videoUrl: '/videos/sample5.mp4',
    services: ['Script', 'Production', 'Edit', 'Motion Graphics', 'VFX'],
    kpis: {
      views: 680000,
      clicks: 28000,
      engagement: '5.2%'
    }
  },
  {
    id: '6',
    title: 'Behind The Scenes Reel',
    client: 'Local Restaurant Chain',
    type: 'reel',
    thumbnail: '/images/videos/video6.jpg',
    videoUrl: '/videos/sample6.mp4',
    services: ['Production', 'Edit', 'Color Grading'],
    kpis: {
      views: 320000,
      engagement: '9.7%'
    }
  }
];
