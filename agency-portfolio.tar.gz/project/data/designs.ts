export interface DesignItem {
  id: string;
  title: string;
  client: string;
  category: 'social-media' | 'branding' | 'posters' | 'campaign';
  image: string;
  result: string;
  goal: string;
  platform: string;
}

export const designs: DesignItem[] = [
  {
    id: '1',
    title: 'Summer Campaign 2024',
    client: 'Fashion Brand X',
    category: 'social-media',
    image: '/images/designs/design1.jpg',
    result: 'Increased engagement by 230%',
    goal: 'Launch summer collection with high social engagement',
    platform: 'Instagram & Facebook'
  },
  {
    id: '2',
    title: 'Brand Identity Redesign',
    client: 'Tech Startup Y',
    category: 'branding',
    image: '/images/designs/design2.jpg',
    result: 'Brand recognition up 150%',
    goal: 'Complete rebrand for market repositioning',
    platform: 'All Platforms'
  },
  {
    id: '3',
    title: 'Product Launch Poster',
    client: 'Consumer Electronics Z',
    category: 'posters',
    image: '/images/designs/design3.jpg',
    result: 'Generated 5K+ pre-orders',
    goal: 'Create buzz for new product launch',
    platform: 'Print & Digital'
  },
  {
    id: '4',
    title: 'Holiday Campaign Creatives',
    client: 'Retail Chain A',
    category: 'campaign',
    image: '/images/designs/design4.jpg',
    result: '3.2x ROAS on paid social',
    goal: 'Drive holiday season sales',
    platform: 'Facebook & Instagram Ads'
  },
  {
    id: '5',
    title: 'Influencer Content Series',
    client: 'Beauty Brand B',
    category: 'social-media',
    image: '/images/designs/design5.jpg',
    result: '2M+ organic reach',
    goal: 'Build influencer partnership content',
    platform: 'Instagram & TikTok'
  },
  {
    id: '6',
    title: 'Corporate Branding Package',
    client: 'Finance Company C',
    category: 'branding',
    image: '/images/designs/design6.jpg',
    result: 'Complete brand system delivered',
    goal: 'Establish professional brand presence',
    platform: 'All Touchpoints'
  }
];
