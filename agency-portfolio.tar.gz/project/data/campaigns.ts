export interface Campaign {
  id: string;
  name: string;
  client: string;
  platform: 'meta' | 'tiktok' | 'google';
  spend: number;
  results: number;
  cpa: number;
  roas: number;
  duration: string;
  goal: string;
  screenshot: string;
  resultsOverTime: { date: string; value: number }[];
}

export const campaigns: Campaign[] = [
  {
    id: '1',
    name: 'Spring Sale Campaign',
    client: 'E-commerce Store',
    platform: 'meta',
    spend: 15000,
    results: 450,
    cpa: 33.33,
    roas: 4.2,
    duration: 'March 1-31, 2024',
    goal: 'Drive spring season purchases with 3x ROAS minimum',
    screenshot: '/images/ads/campaign1.png',
    resultsOverTime: [
      { date: 'Week 1', value: 80 },
      { date: 'Week 2', value: 120 },
      { date: 'Week 3', value: 140 },
      { date: 'Week 4', value: 110 }
    ]
  },
  {
    id: '2',
    name: 'Lead Generation',
    client: 'SaaS Platform',
    platform: 'meta',
    spend: 8500,
    results: 320,
    cpa: 26.56,
    roas: 5.8,
    duration: 'Feb 15 - Mar 15, 2024',
    goal: 'Generate qualified B2B leads under $30 CPA',
    screenshot: '/images/ads/campaign2.png',
    resultsOverTime: [
      { date: 'Week 1', value: 60 },
      { date: 'Week 2', value: 85 },
      { date: 'Week 3', value: 95 },
      { date: 'Week 4', value: 80 }
    ]
  },
  {
    id: '3',
    name: 'Brand Awareness',
    client: 'Local Restaurant Chain',
    platform: 'meta',
    spend: 5200,
    results: 180,
    cpa: 28.89,
    roas: 3.6,
    duration: 'Jan 10 - Feb 10, 2024',
    goal: 'Increase foot traffic and online orders',
    screenshot: '/images/ads/campaign3.png',
    resultsOverTime: [
      { date: 'Week 1', value: 35 },
      { date: 'Week 2', value: 48 },
      { date: 'Week 3', value: 52 },
      { date: 'Week 4', value: 45 }
    ]
  },
  {
    id: '4',
    name: 'Product Launch',
    client: 'Tech Gadget Brand',
    platform: 'meta',
    spend: 22000,
    results: 680,
    cpa: 32.35,
    roas: 6.2,
    duration: 'April 1-30, 2024',
    goal: 'Launch new product with maximum reach and conversions',
    screenshot: '/images/ads/campaign4.png',
    resultsOverTime: [
      { date: 'Week 1', value: 140 },
      { date: 'Week 2', value: 180 },
      { date: 'Week 3', value: 200 },
      { date: 'Week 4', value: 160 }
    ]
  }
];

export const getCampaignKPIs = (platformFilter: 'meta' | 'tiktok' | 'google' | 'all' = 'all') => {
  const filtered = platformFilter === 'all'
    ? campaigns
    : campaigns.filter(c => c.platform === platformFilter);

  const totalSpend = filtered.reduce((sum, c) => sum + c.spend, 0);
  const totalResults = filtered.reduce((sum, c) => sum + c.results, 0);
  const avgCPA = totalResults > 0 ? totalSpend / totalResults : 0;
  const avgROAS = filtered.reduce((sum, c) => sum + c.roas, 0) / filtered.length;

  return {
    totalSpend,
    totalResults,
    avgCPA,
    avgROAS: avgROAS || 0
  };
};
