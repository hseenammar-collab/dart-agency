export interface CaseStudy {
  id: string;
  title: string;
  client: string;
  industry: string;
  goal: string;
  timePeriod: string;
  mainImage: string;
  results: {
    metric: string;
    value: string;
  }[];
}

export const caseStudies: CaseStudy[] = [
  {
    id: '1',
    title: 'E-commerce Scale Campaign',
    client: 'Fashion Brand X',
    industry: 'Fashion & Retail',
    goal: 'Scale online sales while maintaining profitability',
    timePeriod: 'Q1 2024 - 3 Months',
    mainImage: '/images/case-studies/case1.jpg',
    results: [
      { metric: 'Revenue Generated', value: '$320K' },
      { metric: 'ROAS', value: '4.8x' },
      { metric: 'Ad Spend', value: '$67K' },
      { metric: 'Conversions', value: '2,450' }
    ]
  },
  {
    id: '2',
    title: 'Lead Generation System',
    client: 'SaaS Platform',
    industry: 'Software & Technology',
    goal: 'Build predictable B2B lead generation pipeline',
    timePeriod: 'Feb - Apr 2024',
    mainImage: '/images/case-studies/case2.jpg',
    results: [
      { metric: 'Qualified Leads', value: '850' },
      { metric: 'Cost Per Lead', value: '$28' },
      { metric: 'Conversion Rate', value: '12.5%' },
      { metric: 'Pipeline Value', value: '$2.1M' }
    ]
  },
  {
    id: '3',
    title: 'Brand Launch Campaign',
    client: 'Tech Gadget Brand',
    industry: 'Consumer Electronics',
    goal: 'Launch new product to target audience',
    timePeriod: 'March - May 2024',
    mainImage: '/images/case-studies/case3.jpg',
    results: [
      { metric: 'Reach', value: '2.5M' },
      { metric: 'Pre-orders', value: '5,200' },
      { metric: 'Social Engagement', value: '8.9%' },
      { metric: 'Brand Awareness', value: '+180%' }
    ]
  },
  {
    id: '4',
    title: 'Restaurant Chain Growth',
    client: 'Local Restaurant Chain',
    industry: 'Food & Beverage',
    goal: 'Drive foot traffic and online orders',
    timePeriod: 'Jan - Mar 2024',
    mainImage: '/images/case-studies/case4.jpg',
    results: [
      { metric: 'New Customers', value: '3,850' },
      { metric: 'Revenue Increase', value: '+45%' },
      { metric: 'Average Order Value', value: '+22%' },
      { metric: 'Customer Retention', value: '68%' }
    ]
  }
];
