'use client';

import { useState, useEffect } from 'react';
import { Globe } from 'lucide-react';
import { useLanguage } from '@/lib/language-context';
import { Button } from './ui/button';

export function Navigation() {
  const [scrolled, setScrolled] = useState(false);
  const { language, setLanguage, t, dir } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'ar' : 'en');
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-background/80 backdrop-blur-lg border-b border-border shadow-lg'
          : 'bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-20">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollToSection('hero')}>
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-primary flex items-center justify-center shadow-neon">
              <span className="text-lg md:text-xl font-bold text-primary-foreground">[A]</span>
            </div>
            <span className="text-lg md:text-xl font-bold hidden sm:block">[AGENCY_NAME]</span>
          </div>

          <div className="hidden lg:flex items-center gap-1">
            <NavLink onClick={() => scrollToSection('hero')}>{t.nav.home}</NavLink>
            <NavLink onClick={() => scrollToSection('design')}>{t.nav.design}</NavLink>
            <NavLink onClick={() => scrollToSection('ads')}>{t.nav.ads}</NavLink>
            <NavLink onClick={() => scrollToSection('video')}>{t.nav.video}</NavLink>
            <NavLink onClick={() => scrollToSection('cases')}>{t.nav.cases}</NavLink>
            <NavLink onClick={() => scrollToSection('contact')}>{t.nav.contact}</NavLink>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleLanguage}
              className="gap-2 hover:bg-primary/10"
            >
              <Globe className="w-4 h-4" />
              <span className="font-semibold">{language === 'en' ? 'AR' : 'EN'}</span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}

function NavLink({
  children,
  onClick,
}: {
  children: React.ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="px-4 py-2 text-sm font-medium text-foreground/80 hover:text-foreground hover:bg-primary/10 rounded-lg transition-all duration-200"
    >
      {children}
    </button>
  );
}
