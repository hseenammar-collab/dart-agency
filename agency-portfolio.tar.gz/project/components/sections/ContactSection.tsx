'use client';

import { useState } from 'react';
import { useLanguage } from '@/lib/language-context';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Instagram, Facebook, Send, MessageCircle } from 'lucide-react';

export function ContactSection() {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    serviceType: '',
    budget: '',
    message: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
  };

  return (
    <section id="contact" className="py-20 md:py-32 relative bg-secondary/30">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-accent/5 to-transparent" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            {t.contact.title}
          </h2>
          <p className="text-lg md:text-xl text-foreground/70 max-w-3xl mx-auto">
            {t.contact.description}
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="glass-card-strong rounded-3xl p-6 md:p-10 shadow-3d">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">{t.contact.form.name}</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="bg-background/50 border-border focus:border-primary"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">{t.contact.form.email}</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-background/50 border-border focus:border-primary"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">
                  {t.contact.form.company}
                </label>
                <Input
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  placeholder={t.contact.form.companyPlaceholder}
                  className="bg-background/50 border-border focus:border-primary"
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-medium">{t.contact.form.serviceType}</label>
                  <Select
                    value={formData.serviceType}
                    onValueChange={(value) => setFormData({ ...formData, serviceType: value })}
                  >
                    <SelectTrigger className="bg-background/50 border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="design">{t.contact.form.services.design}</SelectItem>
                      <SelectItem value="ads">{t.contact.form.services.ads}</SelectItem>
                      <SelectItem value="video">{t.contact.form.services.video}</SelectItem>
                      <SelectItem value="full">{t.contact.form.services.full}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">{t.contact.form.budget}</label>
                  <Select
                    value={formData.budget}
                    onValueChange={(value) => setFormData({ ...formData, budget: value })}
                  >
                    <SelectTrigger className="bg-background/50 border-border">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="small">{t.contact.form.budgetRanges.small}</SelectItem>
                      <SelectItem value="medium">{t.contact.form.budgetRanges.medium}</SelectItem>
                      <SelectItem value="large">{t.contact.form.budgetRanges.large}</SelectItem>
                      <SelectItem value="enterprise">{t.contact.form.budgetRanges.enterprise}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">{t.contact.form.message}</label>
                <Textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder={t.contact.form.messagePlaceholder}
                  rows={6}
                  className="bg-background/50 border-border focus:border-primary resize-none"
                  required
                />
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full bg-primary hover:bg-primary/90 shadow-3d hover:shadow-3d-hover transition-all duration-300 hover:-translate-y-1"
              >
                {t.contact.form.submit}
              </Button>
            </form>

            <div className="mt-12 pt-8 border-t border-border">
              <h3 className="text-lg font-semibold text-center mb-6">{t.contact.social.title}</h3>
              <div className="flex justify-center gap-4">
                <SocialButton
                  icon={<Instagram className="w-5 h-5" />}
                  label={t.contact.social.instagram}
                  href="https://instagram.com"
                />
                <SocialButton
                  icon={<Facebook className="w-5 h-5" />}
                  label={t.contact.social.facebook}
                  href="https://facebook.com"
                />
                <SocialButton
                  icon={<Send className="w-5 h-5" />}
                  label={t.contact.social.tiktok}
                  href="https://tiktok.com"
                />
                <SocialButton
                  icon={<MessageCircle className="w-5 h-5" />}
                  label={t.contact.social.whatsapp}
                  href="https://wa.me/"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SocialButton({
  icon,
  label,
  href,
}: {
  icon: React.ReactNode;
  label: string;
  href: string;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="glass-card hover:glass-card-strong rounded-xl p-4 flex flex-col items-center gap-2 hover:scale-110 hover:shadow-3d transition-all duration-300 group"
    >
      <div className="text-primary group-hover:text-accent transition-colors">
        {icon}
      </div>
      <span className="text-xs text-foreground/60 group-hover:text-foreground transition-colors">
        {label}
      </span>
    </a>
  );
}
