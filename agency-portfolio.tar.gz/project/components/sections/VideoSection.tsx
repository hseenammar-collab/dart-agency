'use client';

import { useState } from 'react';
import { videos, VideoItem } from '@/data/videos';
import { useLanguage } from '@/lib/language-context';
import { Badge } from '../ui/badge';
import { Dialog, DialogContent } from '../ui/dialog';
import { Play, Eye, MousePointer, TrendingUp } from 'lucide-react';

export function VideoSection() {
  const { t } = useLanguage();
  const [selectedVideo, setSelectedVideo] = useState<VideoItem | null>(null);

  return (
    <section id="video" className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            {t.video.title}
          </h2>
          <p className="text-lg md:text-xl text-foreground/70 max-w-3xl mx-auto">
            {t.video.description}
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {videos.map((video, index) => (
            <VideoCard
              key={video.id}
              video={video}
              index={index}
              onClick={() => setSelectedVideo(video)}
            />
          ))}
        </div>
      </div>

      <Dialog open={!!selectedVideo} onOpenChange={() => setSelectedVideo(null)}>
        <DialogContent className="max-w-5xl bg-secondary/95 backdrop-blur-xl border-border">
          {selectedVideo && (
            <div className="space-y-6">
              <div>
                <h3 className="text-2xl font-bold mb-2">{selectedVideo.title}</h3>
                <p className="text-foreground/60">{selectedVideo.client}</p>
              </div>

              <div className="aspect-video bg-black rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <Play className="w-16 h-16 text-white/60 mx-auto mb-2" />
                  <p className="text-white/60">Video: {selectedVideo.videoUrl}</p>
                </div>
              </div>

              <div>
                <h4 className="font-semibold mb-3">{t.video.whatWeDid}</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedVideo.services.map((service) => (
                    <Badge key={service} variant="secondary" className="bg-primary/20 text-primary">
                      {service}
                    </Badge>
                  ))}
                </div>
              </div>

              {selectedVideo.kpis && (
                <div>
                  <h4 className="font-semibold mb-3">{t.video.performance}</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {selectedVideo.kpis.views && (
                      <div className="glass-card rounded-lg p-4">
                        <Eye className="w-5 h-5 text-primary mb-2" />
                        <div className="text-2xl font-bold">{selectedVideo.kpis.views.toLocaleString()}</div>
                        <div className="text-sm text-foreground/60">{t.video.views}</div>
                      </div>
                    )}
                    {selectedVideo.kpis.clicks && (
                      <div className="glass-card rounded-lg p-4">
                        <MousePointer className="w-5 h-5 text-accent mb-2" />
                        <div className="text-2xl font-bold">{selectedVideo.kpis.clicks.toLocaleString()}</div>
                        <div className="text-sm text-foreground/60">{t.video.clicks}</div>
                      </div>
                    )}
                    {selectedVideo.kpis.engagement && (
                      <div className="glass-card rounded-lg p-4">
                        <TrendingUp className="w-5 h-5 text-primary mb-2" />
                        <div className="text-2xl font-bold">{selectedVideo.kpis.engagement}</div>
                        <div className="text-sm text-foreground/60">{t.video.engagement}</div>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function VideoCard({
  video,
  index,
  onClick,
}: {
  video: VideoItem;
  index: number;
  onClick: () => void;
}) {
  const { t } = useLanguage();
  const [isHovered, setIsHovered] = useState(false);

  const getTypeBadgeColor = (type: VideoItem['type']) => {
    switch (type) {
      case 'ad':
        return 'bg-accent/20 text-accent border-accent/30';
      case 'reel':
        return 'bg-primary/20 text-primary border-primary/30';
      case 'brand-film':
        return 'bg-chart-3/20 text-chart-3 border-chart-3/30';
      case 'social':
        return 'bg-chart-4/20 text-chart-4 border-chart-4/30';
    }
  };

  return (
    <div
      className="group relative cursor-pointer"
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        transform: `translateY(${index % 3 === 1 ? '20px' : '0px'})`,
      }}
    >
      <div
        className={`glass-card rounded-2xl overflow-hidden shadow-3d transition-all duration-300 ${
          isHovered ? 'shadow-3d-hover -translate-y-2 rotate-1' : ''
        }`}
      >
        <div className="aspect-video w-full bg-gradient-to-br from-accent/30 to-primary/30 flex items-center justify-center relative overflow-hidden">
          <span className="text-foreground/40 text-sm">Thumbnail: {video.thumbnail}</span>
          <div
            className={`absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity duration-300 flex items-center justify-center ${
              isHovered ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="text-center">
              <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-3 shadow-neon">
                <Play className="w-8 h-8 text-primary-foreground ml-1" fill="currentColor" />
              </div>
              <p className="text-white font-semibold">{t.video.play}</p>
            </div>
          </div>
        </div>
        <div className="p-6">
          <Badge variant="secondary" className={`mb-3 ${getTypeBadgeColor(video.type)}`}>
            {video.type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
          </Badge>
          <h3 className="text-xl font-semibold mb-2">{video.title}</h3>
          <p className="text-foreground/60 mb-3">{video.client}</p>
          {video.kpis?.views && (
            <div className="flex items-center gap-2 text-sm text-foreground/60">
              <Eye className="w-4 h-4" />
              <span>{video.kpis.views.toLocaleString()} views</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
