'use client';

import { useState } from 'react';
import { campaigns, getCampaignKPIs, Campaign } from '@/data/campaigns';
import { useLanguage } from '@/lib/language-context';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { DollarSign, Target, TrendingUp, Activity } from 'lucide-react';

type Platform = 'meta' | 'tiktok' | 'google';

export function AdsSection() {
  const { t } = useLanguage();
  const [platform, setPlatform] = useState<Platform>('meta');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);

  const kpis = getCampaignKPIs(platform);
  const filteredCampaigns = campaigns.filter(c => c.platform === platform);

  return (
    <section id="ads" className="py-20 md:py-32 relative bg-secondary/30">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-accent/5 to-transparent" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            {t.ads.title}
          </h2>
          <p className="text-lg md:text-xl text-foreground/70 max-w-3xl mx-auto">
            {t.ads.description}
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="glass-card-strong rounded-3xl p-6 md:p-8 shadow-3d">
            <div className="flex flex-wrap gap-3 mb-8 border-b border-border pb-4">
              <TabButton
                active={platform === 'meta'}
                onClick={() => setPlatform('meta')}
              >
                {t.ads.tabs.meta}
              </TabButton>
              <TabButton
                active={platform === 'tiktok'}
                onClick={() => setPlatform('tiktok')}
                disabled
              >
                {t.ads.tabs.tiktok}
              </TabButton>
              <TabButton
                active={platform === 'google'}
                onClick={() => setPlatform('google')}
                disabled
              >
                {t.ads.tabs.google}
              </TabButton>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
              <KPICard
                icon={<DollarSign className="w-6 h-6" />}
                title={t.ads.totalSpend}
                value={`$${kpis.totalSpend.toLocaleString()}`}
                color="primary"
              />
              <KPICard
                icon={<Target className="w-6 h-6" />}
                title={t.ads.totalResults}
                value={kpis.totalResults.toLocaleString()}
                color="accent"
              />
              <KPICard
                icon={<Activity className="w-6 h-6" />}
                title={t.ads.avgCPA}
                value={`$${kpis.avgCPA.toFixed(2)}`}
                color="primary"
              />
              <KPICard
                icon={<TrendingUp className="w-6 h-6" />}
                title={t.ads.avgROAS}
                value={`${kpis.avgROAS.toFixed(1)}x`}
                color="accent"
              />
            </div>

            <div className="glass-card rounded-2xl p-4 md:p-6">
              <h3 className="text-xl font-semibold mb-4">{t.ads.campaigns}</h3>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-2 text-sm font-medium text-foreground/60">
                        {t.ads.table.campaign}
                      </th>
                      <th className="text-left py-3 px-2 text-sm font-medium text-foreground/60">
                        {t.ads.table.client}
                      </th>
                      <th className="text-right py-3 px-2 text-sm font-medium text-foreground/60">
                        {t.ads.table.spend}
                      </th>
                      <th className="text-right py-3 px-2 text-sm font-medium text-foreground/60">
                        {t.ads.table.results}
                      </th>
                      <th className="text-right py-3 px-2 text-sm font-medium text-foreground/60">
                        {t.ads.table.roas}
                      </th>
                      <th className="text-right py-3 px-2"></th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredCampaigns.map((campaign) => (
                      <tr
                        key={campaign.id}
                        className="border-b border-border/50 hover:bg-primary/5 transition-colors"
                      >
                        <td className="py-4 px-2 font-medium">{campaign.name}</td>
                        <td className="py-4 px-2 text-foreground/60">{campaign.client}</td>
                        <td className="py-4 px-2 text-right">${campaign.spend.toLocaleString()}</td>
                        <td className="py-4 px-2 text-right">{campaign.results}</td>
                        <td className="py-4 px-2 text-right">
                          <span className="text-accent font-semibold">{campaign.roas}x</span>
                        </td>
                        <td className="py-4 px-2 text-right">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setSelectedCampaign(campaign)}
                            className="hover:bg-primary/10"
                          >
                            {t.ads.viewDetails}
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Dialog open={!!selectedCampaign} onOpenChange={() => setSelectedCampaign(null)}>
        <DialogContent className="max-w-4xl bg-secondary/95 backdrop-blur-xl border-border">
          {selectedCampaign && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedCampaign.name}</DialogTitle>
              </DialogHeader>
              <div className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <span className="text-sm text-foreground/60">{t.ads.table.client}: </span>
                    <span className="text-foreground font-medium">{selectedCampaign.client}</span>
                  </div>
                  <div>
                    <span className="text-sm text-foreground/60">{t.ads.duration}: </span>
                    <span className="text-foreground font-medium">{selectedCampaign.duration}</span>
                  </div>
                </div>
                <div>
                  <span className="text-sm text-foreground/60">{t.ads.goal}: </span>
                  <p className="text-foreground mt-1">{selectedCampaign.goal}</p>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="glass-card rounded-lg p-4">
                    <div className="text-2xl font-bold text-primary">
                      ${selectedCampaign.spend.toLocaleString()}
                    </div>
                    <div className="text-sm text-foreground/60">{t.ads.table.spend}</div>
                  </div>
                  <div className="glass-card rounded-lg p-4">
                    <div className="text-2xl font-bold text-accent">
                      {selectedCampaign.results}
                    </div>
                    <div className="text-sm text-foreground/60">{t.ads.table.results}</div>
                  </div>
                  <div className="glass-card rounded-lg p-4">
                    <div className="text-2xl font-bold text-primary">
                      ${selectedCampaign.cpa.toFixed(2)}
                    </div>
                    <div className="text-sm text-foreground/60">{t.ads.table.cpa}</div>
                  </div>
                  <div className="glass-card rounded-lg p-4">
                    <div className="text-2xl font-bold text-accent">
                      {selectedCampaign.roas}x
                    </div>
                    <div className="text-sm text-foreground/60">{t.ads.table.roas}</div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold mb-3">{t.ads.resultsOverTime}</h4>
                  <div className="glass-card rounded-lg p-4">
                    <div className="flex items-end justify-between h-40 gap-2">
                      {selectedCampaign.resultsOverTime.map((item, index) => (
                        <div key={index} className="flex-1 flex flex-col items-center gap-2">
                          <div
                            className="w-full bg-gradient-to-t from-primary to-accent rounded-t-lg transition-all duration-500"
                            style={{
                              height: `${(item.value / Math.max(...selectedCampaign.resultsOverTime.map(i => i.value))) * 100}%`,
                            }}
                          />
                          <span className="text-xs text-foreground/60">{item.date}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="aspect-video bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg flex items-center justify-center">
                  <span className="text-foreground/40">Screenshot: {selectedCampaign.screenshot}</span>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function TabButton({
  active,
  onClick,
  disabled,
  children,
}: {
  active: boolean;
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
}) {
  return (
    <Button
      variant={active ? 'default' : 'ghost'}
      onClick={onClick}
      disabled={disabled}
      className={`transition-all duration-300 ${
        active
          ? 'bg-primary shadow-neon'
          : 'hover:bg-primary/10'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    >
      {children}
    </Button>
  );
}

function KPICard({
  icon,
  title,
  value,
  color,
}: {
  icon: React.ReactNode;
  title: string;
  value: string;
  color: 'primary' | 'accent';
}) {
  return (
    <div className="glass-card rounded-2xl p-6 hover:shadow-3d-hover transition-all duration-300">
      <div className={`w-12 h-12 rounded-xl ${color === 'primary' ? 'bg-primary/20 text-primary' : 'bg-accent/20 text-accent'} flex items-center justify-center mb-3`}>
        {icon}
      </div>
      <div className="text-2xl md:text-3xl font-bold mb-1">{value}</div>
      <div className="text-sm text-foreground/60">{title}</div>
    </div>
  );
}
