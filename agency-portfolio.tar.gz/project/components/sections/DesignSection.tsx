'use client';

import { useState } from 'react';
import { designs, DesignItem } from '@/data/designs';
import { useLanguage } from '@/lib/language-context';
import { Button } from '../ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../ui/dialog';
import { Badge } from '../ui/badge';

type FilterCategory = 'all' | 'social-media' | 'branding' | 'posters' | 'campaign';

export function DesignSection() {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<FilterCategory>('all');
  const [selectedDesign, setSelectedDesign] = useState<DesignItem | null>(null);

  const filteredDesigns = filter === 'all'
    ? designs
    : designs.filter(d => d.category === filter);

  return (
    <section id="design" className="py-20 md:py-32 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            {t.design.title}
          </h2>
          <p className="text-lg md:text-xl text-foreground/70 max-w-3xl mx-auto">
            {t.design.description}
          </p>
        </div>

        <div className="flex flex-wrap gap-3 justify-center mb-12">
          <FilterButton
            active={filter === 'all'}
            onClick={() => setFilter('all')}
          >
            {t.design.filters.all}
          </FilterButton>
          <FilterButton
            active={filter === 'social-media'}
            onClick={() => setFilter('social-media')}
          >
            {t.design.filters.socialMedia}
          </FilterButton>
          <FilterButton
            active={filter === 'branding'}
            onClick={() => setFilter('branding')}
          >
            {t.design.filters.branding}
          </FilterButton>
          <FilterButton
            active={filter === 'posters'}
            onClick={() => setFilter('posters')}
          >
            {t.design.filters.posters}
          </FilterButton>
          <FilterButton
            active={filter === 'campaign'}
            onClick={() => setFilter('campaign')}
          >
            {t.design.filters.campaign}
          </FilterButton>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {filteredDesigns.map((design) => (
            <DesignCard
              key={design.id}
              design={design}
              onClick={() => setSelectedDesign(design)}
            />
          ))}
        </div>
      </div>

      <Dialog open={!!selectedDesign} onOpenChange={() => setSelectedDesign(null)}>
        <DialogContent className="max-w-3xl bg-secondary/95 backdrop-blur-xl border-border">
          {selectedDesign && (
            <>
              <DialogHeader>
                <DialogTitle className="text-2xl">{selectedDesign.title}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="aspect-video w-full bg-gradient-to-br from-primary/30 to-accent/30 rounded-lg flex items-center justify-center">
                  <span className="text-foreground/40">Image: {selectedDesign.image}</span>
                </div>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-foreground/60">{t.design.goal}: </span>
                    <span className="text-foreground">{selectedDesign.goal}</span>
                  </div>
                  <div>
                    <span className="text-sm text-foreground/60">{t.design.platform}: </span>
                    <span className="text-foreground">{selectedDesign.platform}</span>
                  </div>
                  <div>
                    <span className="text-sm text-foreground/60">{t.design.result}: </span>
                    <span className="text-accent font-semibold">{selectedDesign.result}</span>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
}

function FilterButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <Button
      variant={active ? 'default' : 'outline'}
      onClick={onClick}
      className={`transition-all duration-300 ${
        active
          ? 'bg-primary shadow-neon hover:bg-primary/90'
          : 'hover:bg-primary/10 hover:border-primary'
      }`}
    >
      {children}
    </Button>
  );
}

function DesignCard({
  design,
  onClick,
}: {
  design: DesignItem;
  onClick: () => void;
}) {
  const { t } = useLanguage();
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="group relative cursor-pointer"
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div
        className={`glass-card rounded-2xl overflow-hidden shadow-3d transition-all duration-300 ${
          isHovered ? 'shadow-3d-hover -translate-y-2' : ''
        }`}
        style={{
          transform: isHovered ? 'perspective(1000px) rotateX(2deg)' : 'none',
        }}
      >
        <div className="aspect-video w-full bg-gradient-to-br from-primary/30 to-accent/30 flex items-center justify-center relative overflow-hidden">
          <span className="text-foreground/40 text-sm">Image: {design.image}</span>
          <div
            className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 flex items-center justify-center ${
              isHovered ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <div className="text-center px-4">
              <p className="text-accent font-semibold text-lg mb-2">{design.result}</p>
              <Button size="sm" variant="outline" className="border-accent text-accent hover:bg-accent hover:text-accent-foreground">
                {t.design.viewCase}
              </Button>
            </div>
          </div>
        </div>
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-2">{design.title}</h3>
          <p className="text-foreground/60 mb-3">{design.client}</p>
          <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
            {design.category.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
          </Badge>
        </div>
      </div>
    </div>
  );
}
