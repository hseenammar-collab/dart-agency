'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '../ui/button';
import { useLanguage } from '@/lib/language-context';
import { BarChart3, Image, Play } from 'lucide-react';

export function HeroSection() {
  const { t } = useLanguage();
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      const x = (e.clientX - rect.left - rect.width / 2) / 20;
      const y = (e.clientY - rect.top - rect.height / 2) / 20;
      setMousePosition({ x, y });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20"
    >
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12 md:mb-16">
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-pulse">
                {t.hero.headline}
              </span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-foreground/80 mb-8 max-w-3xl mx-auto leading-relaxed">
              {t.hero.subheadline}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                onClick={() => scrollToSection('design')}
                className="text-base md:text-lg px-8 py-6 bg-primary hover:bg-primary/90 shadow-3d hover:shadow-3d-hover transition-all duration-300 hover:-translate-y-1"
              >
                {t.hero.viewPortfolio}
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => scrollToSection('ads')}
                className="text-base md:text-lg px-8 py-6 border-2 border-accent text-accent hover:bg-accent hover:text-accent-foreground shadow-3d hover:shadow-3d-hover transition-all duration-300 hover:-translate-y-1"
              >
                {t.hero.viewDashboard}
              </Button>
            </div>
          </div>

          <div
            ref={cardRef}
            className="max-w-4xl mx-auto perspective-1000"
            style={{
              transform: `rotateX(${-mousePosition.y}deg) rotateY(${mousePosition.x}deg)`,
              transition: 'transform 0.1s ease-out',
            }}
          >
            <div className="glass-card-strong rounded-3xl p-6 md:p-8 shadow-3d transform-3d">
              <div className="grid md:grid-cols-3 gap-4 md:gap-6">
                <div className="glass-card rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-primary/10 transition-all duration-300 group cursor-pointer">
                  <div className="w-16 h-16 rounded-xl bg-primary/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Image className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-lg mb-1">{t.hero.sampleCreative}</h3>
                    <div className="w-full h-24 bg-gradient-to-br from-primary/30 to-accent/30 rounded-lg flex items-center justify-center">
                      <span className="text-xs text-foreground/60">Design Preview</span>
                    </div>
                  </div>
                </div>

                <div className="glass-card rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-accent/10 transition-all duration-300 group cursor-pointer">
                  <div className="w-16 h-16 rounded-xl bg-accent/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <BarChart3 className="w-8 h-8 text-accent" />
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-lg mb-1">{t.hero.adResults}</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-foreground/60">ROAS:</span>
                        <span className="text-accent font-semibold">4.8x</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-foreground/60">CPA:</span>
                        <span className="text-accent font-semibold">$28</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="glass-card rounded-2xl p-6 flex flex-col items-center justify-center gap-4 hover:bg-primary/10 transition-all duration-300 group cursor-pointer">
                  <div className="w-16 h-16 rounded-xl bg-primary/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <Play className="w-8 h-8 text-primary" />
                  </div>
                  <div className="text-center">
                    <h3 className="font-semibold text-lg mb-1">{t.hero.videoPreview}</h3>
                    <div className="w-full h-24 bg-gradient-to-br from-accent/30 to-primary/30 rounded-lg flex items-center justify-center">
                      <Play className="w-10 h-10 text-foreground/40" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-foreground/30 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-foreground/30 rounded-full" />
        </div>
      </div>
    </section>
  );
}
