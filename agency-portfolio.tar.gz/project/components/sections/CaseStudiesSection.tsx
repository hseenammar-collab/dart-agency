'use client';

import { useState } from 'react';
import { caseStudies } from '@/data/caseStudies';
import { useLanguage } from '@/lib/language-context';
import { Button } from '../ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

export function CaseStudiesSection() {
  const { t, dir } = useLanguage();
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % caseStudies.length);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + caseStudies.length) % caseStudies.length);
  };

  const currentCase = caseStudies[currentIndex];

  return (
    <section id="cases" className="py-20 md:py-32 relative bg-secondary/30">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-accent/5 to-transparent" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            {t.cases.title}
          </h2>
          <p className="text-lg md:text-xl text-foreground/70 max-w-3xl mx-auto">
            {t.cases.description}
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="glass-card-strong rounded-3xl p-6 md:p-10 shadow-3d relative overflow-hidden">
            <div
              className="grid md:grid-cols-2 gap-8 md:gap-12 items-center transition-all duration-500"
              style={{
                transform: `perspective(1000px) rotateY(${dir === 'rtl' ? '2deg' : '-2deg'})`,
              }}
            >
              <div className="order-2 md:order-1">
                <div className="aspect-[4/3] bg-gradient-to-br from-primary/30 to-accent/30 rounded-2xl flex items-center justify-center shadow-3d">
                  <span className="text-foreground/40">Image: {currentCase.mainImage}</span>
                </div>
              </div>

              <div className="order-1 md:order-2 space-y-6">
                <div>
                  <h3 className="text-3xl md:text-4xl font-bold mb-3">
                    {currentCase.title}
                  </h3>
                  <div className="space-y-2 text-foreground/70">
                    <div>
                      <span className="text-sm text-foreground/50">{t.cases.client}: </span>
                      <span className="font-medium">{currentCase.client}</span>
                    </div>
                    <div>
                      <span className="text-sm text-foreground/50">{t.cases.industry}: </span>
                      <span className="font-medium">{currentCase.industry}</span>
                    </div>
                    <div>
                      <span className="text-sm text-foreground/50">{t.cases.timePeriod}: </span>
                      <span className="font-medium">{currentCase.timePeriod}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-semibold mb-2 text-foreground/80">{t.cases.goal}</h4>
                  <p className="text-foreground/70">{currentCase.goal}</p>
                </div>

                <div>
                  <h4 className="text-lg font-semibold mb-3">{t.cases.results}</h4>
                  <div className="grid grid-cols-2 gap-3">
                    {currentCase.results.map((result, index) => (
                      <div key={index} className="glass-card rounded-xl p-4">
                        <div className="text-2xl font-bold text-accent mb-1">
                          {result.value}
                        </div>
                        <div className="text-sm text-foreground/60">{result.metric}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between mt-8 pt-6 border-t border-border">
              <Button
                variant="outline"
                size="icon"
                onClick={prevSlide}
                className="hover:bg-primary/10 hover:border-primary"
              >
                {dir === 'rtl' ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
              </Button>

              <div className="flex gap-2">
                {caseStudies.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentIndex(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      index === currentIndex
                        ? 'w-8 bg-primary shadow-neon'
                        : 'bg-foreground/30 hover:bg-foreground/50'
                    }`}
                  />
                ))}
              </div>

              <Button
                variant="outline"
                size="icon"
                onClick={nextSlide}
                className="hover:bg-primary/10 hover:border-primary"
              >
                {dir === 'rtl' ? <ChevronLeft className="w-5 h-5" /> : <ChevronRight className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
