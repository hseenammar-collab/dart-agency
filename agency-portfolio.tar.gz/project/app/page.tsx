import { Navigation } from '@/components/Navigation';
import { HeroSection } from '@/components/sections/HeroSection';
import { DesignSection } from '@/components/sections/DesignSection';
import { AdsSection } from '@/components/sections/AdsSection';
import { VideoSection } from '@/components/sections/VideoSection';
import { CaseStudiesSection } from '@/components/sections/CaseStudiesSection';
import { TeamSection } from '@/components/sections/TeamSection';
import { ContactSection } from '@/components/sections/ContactSection';

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <DesignSection />
      <AdsSection />
      <VideoSection />
      <CaseStudiesSection />
      <TeamSection />
      <ContactSection />

      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4 text-center text-foreground/60">
          <p>&copy; 2024 [AGENCY_NAME]. All rights reserved.</p>
        </div>
      </footer>
    </main>
  );
}
