export type Language = 'en' | 'ar';

export const translations = {
  en: {
    nav: {
      home: 'Home',
      design: 'Design Work',
      ads: 'Ad Results',
      video: 'Video Crew',
      cases: 'Case Studies',
      contact: 'Contact'
    },
    hero: {
      headline: 'We design, run ads, and produce video — all in one 3D experience',
      subheadline: 'A full-stack creative marketing agency that delivers measurable results through stunning design, data-driven advertising, and cinematic video production.',
      viewPortfolio: 'View Design Portfolio',
      viewDashboard: 'See Performance Dashboard',
      sampleCreative: 'Sample Creative',
      adResults: 'Ad Results',
      videoPreview: 'Video Preview'
    },
    design: {
      title: 'Graphic Design Portfolio',
      description: 'We craft visually stunning designs for social media, branding, posters, and campaign creatives that drive engagement and conversions.',
      filters: {
        all: 'All',
        socialMedia: 'Social Media',
        branding: 'Branding',
        posters: 'Posters',
        campaign: 'Campaign Creatives'
      },
      viewCase: 'View Case Study',
      goal: 'Goal',
      platform: 'Platform',
      result: 'Result'
    },
    ads: {
      title: 'Ads Performance Dashboard',
      description: 'We manage Meta Ads Manager campaigns and deliver measurable results through data-driven optimization and strategic targeting.',
      totalSpend: 'Total Spend',
      totalResults: 'Total Results',
      avgCPA: 'Average CPA',
      avgROAS: 'Average ROAS',
      campaigns: 'Campaigns',
      tabs: {
        meta: 'Meta Ads',
        tiktok: 'TikTok Ads',
        google: 'Google Ads'
      },
      table: {
        campaign: 'Campaign',
        client: 'Client',
        spend: 'Spend',
        results: 'Results',
        cpa: 'CPA',
        roas: 'ROAS'
      },
      viewDetails: 'View Details',
      campaignDetails: 'Campaign Details',
      duration: 'Duration',
      goal: 'Goal',
      resultsOverTime: 'Results Over Time'
    },
    video: {
      title: 'Video Production Squad',
      description: 'We shoot ads, brand films, and social content that captures attention and drives action.',
      whatWeDid: 'What We Did',
      performance: 'Performance',
      views: 'Views',
      clicks: 'Clicks',
      engagement: 'Engagement',
      play: 'Play Video'
    },
    cases: {
      title: 'Campaign Case Studies',
      description: 'Real results from real campaigns. See how we help brands achieve their goals.',
      client: 'Client',
      industry: 'Industry',
      goal: 'Goal',
      timePeriod: 'Time Period',
      results: 'Results'
    },
    team: {
      title: 'Meet the Team',
      description: 'A unified squad of creatives, strategists, and technical experts working together to deliver exceptional results.'
    },
    contact: {
      title: 'Start a Project',
      description: 'Ready to elevate your brand? Fill out the brief below and let\'s create something amazing together.',
      form: {
        name: 'Name',
        email: 'Email',
        company: 'Company',
        companyPlaceholder: 'Optional',
        serviceType: 'Service Type',
        services: {
          design: 'Design',
          ads: 'Ads Management',
          video: 'Video',
          full: 'Full Package'
        },
        budget: 'Budget Range',
        budgetRanges: {
          small: '$5K - $10K',
          medium: '$10K - $25K',
          large: '$25K - $50K',
          enterprise: '$50K+'
        },
        message: 'Message',
        messagePlaceholder: 'Tell us about your project...',
        submit: 'Send Brief'
      },
      social: {
        title: 'Connect With Us',
        instagram: 'Instagram',
        facebook: 'Facebook',
        tiktok: 'TikTok',
        whatsapp: 'WhatsApp'
      }
    }
  },
  ar: {
    nav: {
      home: 'الرئيسية',
      design: 'أعمال التصميم',
      ads: 'نتائج الإعلانات',
      video: 'فريق الفيديو',
      cases: 'دراسات الحالة',
      contact: 'اتصل بنا'
    },
    hero: {
      headline: 'نصمم، نُدير الإعلانات، ونُنتج الفيديو — كل ذلك في تجربة ثلاثية الأبعاد',
      subheadline: 'وكالة تسويق إبداعية متكاملة تقدم نتائج قابلة للقياس من خلال التصميم المذهل والإعلانات المبنية على البيانات وإنتاج الفيديو السينمائي.',
      viewPortfolio: 'عرض معرض التصميم',
      viewDashboard: 'عرض لوحة الأداء',
      sampleCreative: 'تصميم نموذجي',
      adResults: 'نتائج الإعلانات',
      videoPreview: 'معاينة الفيديو'
    },
    design: {
      title: 'معرض التصميم الجرافيكي',
      description: 'نصنع تصاميم مذهلة بصريًا لوسائل التواصل الاجتماعي والعلامات التجارية والملصقات والحملات الإبداعية التي تحفز التفاعل والتحويلات.',
      filters: {
        all: 'الكل',
        socialMedia: 'وسائل التواصل',
        branding: 'العلامات التجارية',
        posters: 'الملصقات',
        campaign: 'حملات إبداعية'
      },
      viewCase: 'عرض دراسة الحالة',
      goal: 'الهدف',
      platform: 'المنصة',
      result: 'النتيجة'
    },
    ads: {
      title: 'لوحة أداء الإعلانات',
      description: 'ندير حملات Meta Ads Manager ونحقق نتائج قابلة للقياس من خلال التحسين المبني على البيانات والاستهداف الاستراتيجي.',
      totalSpend: 'إجمالي الإنفاق',
      totalResults: 'إجمالي النتائج',
      avgCPA: 'متوسط تكلفة الاكتساب',
      avgROAS: 'متوسط عائد الإنفاق',
      campaigns: 'الحملات',
      tabs: {
        meta: 'إعلانات Meta',
        tiktok: 'إعلانات TikTok',
        google: 'إعلانات Google'
      },
      table: {
        campaign: 'الحملة',
        client: 'العميل',
        spend: 'الإنفاق',
        results: 'النتائج',
        cpa: 'تكلفة الاكتساب',
        roas: 'عائد الإنفاق'
      },
      viewDetails: 'عرض التفاصيل',
      campaignDetails: 'تفاصيل الحملة',
      duration: 'المدة',
      goal: 'الهدف',
      resultsOverTime: 'النتائج عبر الوقت'
    },
    video: {
      title: 'فريق إنتاج الفيديو',
      description: 'نصور الإعلانات وأفلام العلامات التجارية والمحتوى الاجتماعي الذي يجذب الانتباه ويحفز العمل.',
      whatWeDid: 'ما قمنا به',
      performance: 'الأداء',
      views: 'المشاهدات',
      clicks: 'النقرات',
      engagement: 'التفاعل',
      play: 'تشغيل الفيديو'
    },
    cases: {
      title: 'دراسات حالة الحملات',
      description: 'نتائج حقيقية من حملات حقيقية. شاهد كيف نساعد العلامات التجارية على تحقيق أهدافها.',
      client: 'العميل',
      industry: 'الصناعة',
      goal: 'الهدف',
      timePeriod: 'الفترة الزمنية',
      results: 'النتائج'
    },
    team: {
      title: 'تعرف على الفريق',
      description: 'فريق موحد من المبدعين والاستراتيجيين والخبراء التقنيين يعملون معًا لتقديم نتائج استثنائية.'
    },
    contact: {
      title: 'ابدأ مشروعًا',
      description: 'هل أنت مستعد للارتقاء بعلامتك التجارية؟ املأ الموجز أدناه ودعنا نصنع شيئًا رائعًا معًا.',
      form: {
        name: 'الاسم',
        email: 'البريد الإلكتروني',
        company: 'الشركة',
        companyPlaceholder: 'اختياري',
        serviceType: 'نوع الخدمة',
        services: {
          design: 'التصميم',
          ads: 'إدارة الإعلانات',
          video: 'الفيديو',
          full: 'الباقة الكاملة'
        },
        budget: 'نطاق الميزانية',
        budgetRanges: {
          small: '$5K - $10K',
          medium: '$10K - $25K',
          large: '$25K - $50K',
          enterprise: '$50K+'
        },
        message: 'الرسالة',
        messagePlaceholder: 'أخبرنا عن مشروعك...',
        submit: 'إرسال الموجز'
      },
      social: {
        title: 'تواصل معنا',
        instagram: 'إنستجرام',
        facebook: 'فيسبوك',
        tiktok: 'تيك توك',
        whatsapp: 'واتساب'
      }
    }
  }
};

export type TranslationKeys = typeof translations.en;
